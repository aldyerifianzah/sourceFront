const addBooks = []
const RENDER_EVENT = 'render-addbook'


document.addEventListener('DOMContentLoaded', function () {
    const submitForm = document.getElementById('inputBook');
    submitForm.addEventListener('submit', function (event) {
      event.preventDefault();
      addBook();
    });
  });

  function addBook(){
    const title = document.getElementById('inputBookTitle').value;
    const author = document.getElementById('inputBookAuthor').value;
    const year = document.getElementById('inputBookYear').value;

    const generatedID = generateId();
    const addBookObject = generateAddBookObject(generatedID, title, author, year, false) //error
    addBooks.push(addBookObject);

    document.dispatchEvent(new Event(RENDER_EVENT));
  }

  document.addEventListener(RENDER_EVENT, function () {
    console.log(addBooks ); //debug in console browser

    const uncompletedAddBookList = document.getElementById('incompleteBookshelfList');
    uncompletedAddBookList.innerHTML = '';

    const completedAddBookList = document.getElementById('completeBookshelfList');
    completedAddBookList.innerHTML = '';

    for (const addBookItem of addBooks) {
        const addBookElement = makeAddBook(addBookItem);
        if(!addBookItem.isDone)
            uncompletedAddBookList.append(addBookElement);
        else
            completedAddBookList.append(addBookElement);
      }
  });


  function generateId() {
    return +new Date();
  }

  function generateAddBookObject(id, title, author, year, isDone) {
    return {
      id,
      title,
      author,
      year,
      isDone,
    }
  }

  function makeAddBook (addBookObject){
    const textTitle = document.createElement('h3')
    textTitle.innerText = addBookObject.title

    const textAuthor = document.createElement('p')
    textAuthor.innerText =`Author: ${addBookObject.author}`

    const textYear = document.createElement('p')
    textYear.innerText = `Tahun: ${addBookObject.year}`

    //article sedang

    const textContainer = document.createElement('div'); // ?? mungkin dihapus
    textContainer.classList.add('book-item');
    textContainer.append(textTitle, textAuthor, textYear);

    const container = document.createElement('article');//correct
    container.classList.add('book_item');
    container.append(textTitle, textAuthor, textYear);
    container.setAttribute('id', `addBook-${addBookObject.id}`);

    //tombol utility

   const containerUtility = document.createElement('div');
   containerUtility.classList.add('action')


   const doneButton = document.createElement('button');
   doneButton.classList.add('green')
   doneButton.textContent = "selesai dibaca"
   doneButton.addEventListener('click', function(){
    addTaskToCompleted(addBookObject.id)
   })

   const deleteButton = document.createElement('button');
   deleteButton.classList.add('red')
   deleteButton.textContent = 'hapus buku'
   deleteButton.addEventListener('click', function(){
    removeTaskFromCompleted(addBookObject.id);
   })


   containerUtility.append(doneButton, deleteButton)
   container.append(containerUtility)
    return container;

  }

  function addTaskToCompleted (addbookid) {
    const addBookTarget = findAddBook(addbookid);
   
    if (addBookTarget == null) return;
   
    addBookTarget.isDone = true;
    document.dispatchEvent(new Event(RENDER_EVENT));
    saveData();
  }

  function findAddBook(addbookid) {
    for (const addBookItem of addBooks) {
      if (addBook.id === addbookid) {
        return todoItem;
      }
    }
    return null;
  }

  function removeTaskFromCompleted(addBookId) {
    const addBookTarget = findAddBookIndex(addBookId);
   
    if (addBookTarget === -1) return;
   
    addBooks.splice(addBookTarget, 1);
    document.dispatchEvent(new Event(RENDER_EVENT));
    saveData();
  }

  function findAddBookIndex(addBookId) {
        for (const index in addBooks) {
          if (addBooks[index].id === addBookId) {
            return index;
          }
        }
    }

    function  saveData() {
     if  (isStorageExist()){
      const parsed = JSON.stringify(addBooks);
      localStorage.setItem(STORAGE_KEY, parsed);
      document.dispatchEvent(new Event(SAVED_EVENT))
    }
  }